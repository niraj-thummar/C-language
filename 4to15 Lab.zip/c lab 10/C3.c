//. Output of the following program
#include <stdio.h>
int main()
{
 int i = 0, j = 0;
 while (i<5,j<10)
 {
 i++;
 j++;
 }
 printf("%d %d", i, j);
}
/*output 10 10 aavse karan ke ahiya , operetor vapryo chhe je khali jamni baju nu value j jove tethi aahiya j<10 hova thi j nu value 10 thase tethi i and j banne ni value 10 10 thase
*/
