//. Find HCF(hightest commen factor)and LCM(lowest commen factor) of two numbers.
