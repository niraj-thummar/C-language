// Output of the following program
#include<stdio.h>
void main()
{
 int a=25;
 while(a <= 27)
 {
 printf("%d ", a);
 a++;
 }
} 
//  #include<stdio.h>
// void main()
// {
//  while(0)
//  {
//  printf("Hello");
//  }
// }