// Swap ƒrst and last digits of a numb
