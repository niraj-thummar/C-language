#include<stdio.h>
int main()
{
    float a=33.7;
    float c=66;
    float b=66;

    printf("average is %f",(a+b+c)/3.00);
    return 0;
}
