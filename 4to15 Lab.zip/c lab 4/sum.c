#include<stdio.h>
int main()
{
    float a;
    float b;
    printf("enter the number a\n");
    scanf("%f",&a);
    printf("enter number b\n");
    scanf("%f",&b);
    printf("sum is %f",a+b);
    return 0;

}