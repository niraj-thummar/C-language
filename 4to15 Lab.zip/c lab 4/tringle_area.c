#include<stdio.h>
int main()
{
    float h,b;
    printf("enter higth\n");
    scanf("%f",&h);
    printf("enter base\n");
    scanf("%f",&b);
    printf("area of the tringle is %f",(h*b)*.5);
    return 0;
}
