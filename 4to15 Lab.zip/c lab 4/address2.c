#include<stdio.h>
int main()
{
    printf("15,krishnapark soc,\n");
    printf("chapparabhatha road amroli surat\n");
    return 0;
}