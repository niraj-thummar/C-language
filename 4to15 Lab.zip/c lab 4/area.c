#include<stdio.h>
int main()
{
    float rad;
    printf("enter the radius\n");
    scanf("%f",&rad);
    printf("area of the circul is %.3f",3.14*rad*rad);
    return 0;
}