#include <stdio.h>
void main(){
 unsigned char c=290; //error aavse becaus unsigned char ni range 0 to 255 chhe
 printf("%d",c);      //char c='3' lakhay pn '4','6'; na lakhay
}