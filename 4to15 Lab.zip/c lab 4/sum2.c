#include<stdio.h>
int main()
{
    int a=4;
    int b=6;
    printf("sum of a and b is %d",a+b);
    return 0;
}