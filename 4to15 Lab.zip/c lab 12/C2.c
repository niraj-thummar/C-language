// Output of the following program.
#include <stdio.h>
void main()
{
 int i = 0, j = 0;
 for (i = 0; i < 5; i++)
 {
 for (j = 0; j < 1;)
 {
 break;
 }
 printf("Darshan University\n");
 }
}
