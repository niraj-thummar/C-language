 //Shutdown Windows/Linux Shutdown Machine. [#include <stdlib.h> to be used for system
//() function]
#include<stdio.h>
#include<stdlib.h>
void main()
{
    system("shutdown /s /t 0");
}