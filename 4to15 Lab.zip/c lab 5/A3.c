//Check whether given number is positive or negative.
#include<stdio.h>
int main()
{
    int num;
    printf("enter the number\n");
    scanf("%d",&num);
    if(num>=0)
    {
        printf("given number is positive\n");

    }
    else{printf("given number is nagative\n");}
    return 0;
}
