#include <stdio.h>
 void main()
 {
 int x = 5;
 if (true);  //if ma string no lakhi sakay
 printf("hello");
 }