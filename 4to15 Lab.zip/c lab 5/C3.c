//Multiply and divide a number by 2 without using multiplication/division operator.
#include<stdio.h>
int main()
{
    int num;
    printf("enter the number\n");
    scanf("%d",&num);
    
       printf("multiplication is %d\n",num<<1);
       
    printf("division is %d\n",num>>1);

    
    return 0;

    
        
    
}