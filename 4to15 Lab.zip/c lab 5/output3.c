#include <stdio.h>
void main()
{
 int x = 5;
 if (x < 1)
 printf("hello");
 if (x == 5)
 printf("hi");
 else
 printf("no");
}