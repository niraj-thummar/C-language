//Print “Hello World” without using ‘;’ symbol.
#include<stdio.h>
int main()
{
    if(printf("hello world"))
    {

    }
    return 0;
}