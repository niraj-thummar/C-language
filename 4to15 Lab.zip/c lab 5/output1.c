#include<stdio.h>
void main(){
 int x=5;
 if(x=1);{       //error aavse because aaya if pachi ; karel chhe
 printf("%d",x);
 }
 else{
 printf("%d",x);
 }
}
