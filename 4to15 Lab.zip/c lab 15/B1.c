//Delete all duplicate elements from an array
